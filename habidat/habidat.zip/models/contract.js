var moment = require('moment');

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('contract', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    user_id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'user',
        key: 'id'
      }
    },
    sign_date: {
      type: DataTypes.DATE,
      allowNull: true
    },
    termination_date: {
      type: DataTypes.DATE,
      allowNull: true
    },
    amount: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    interest_rate: {
      type: DataTypes.DECIMAL,
      allowNull: true
    },
    period: {
      type: DataTypes.FLOAT,
      allowNull: true
    },
    status: {
      type: DataTypes.STRING,
      allowNull: true
    },
    notes: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'contract',
    freezeTableName: true,
    classMethods: {
    	associate: function(db) {
    		db.contract.hasMany(db.transaction, {
    			as: 'transactions', 
    			foreignKey: 'contract_id'
    		});
    		db.contract.belongsTo(db.user, {
    	          onDelete: "CASCADE",
    	          foreignKey: 'user_id',
    	          as: 'contracts'
    	        });
    	}
    },
    instanceMethods: {
  		calculateInterest: function() {
  			var interest = 0.00;
  			var interest_rate = this.interest_rate;
  			if (this.termination_date && this.transactions.length > 1) {
  				this.transactions.forEach(function(transaction) {
  					interest = interest + transaction.amount;
  				});  	
  				interest = Math.abs(interest);
  			} else {
  				this.transactions.forEach(function(transaction) {
  					interest = interest + transaction.amount * Math.pow (1+(interest_rate/100), moment(Date.now()).diff(transaction.transaction_date, 'days') / 365) - transaction.amount;
  				});
  				interest = Math.ceil(interest*100) / 100;
  			}
  			return interest;
  		},
  		getFetchedTransactions: function() {
  			return this.transactions;
  		},
  		getStatus: function() {
  			return this.termination_date? "Gekündigt" : "Laufend";
  		},
  		getStatusText: function() {
			switch(this.status) {
			case "unknown": 
				return 'Noch kein Vertrag';
			case "sign": 
				return 'Vertrag ist zu unterschreiben';
			case "sent":
				return 'Vertrag ist verschickt';
			case "complete":
				return 'Vertrag abgeschlossen ';
			}
			return "Unbekannt";
		}
    }
  });
};
