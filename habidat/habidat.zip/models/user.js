

module.exports = function(sequelize, DataTypes) {
  var User = sequelize.define('user', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    logon_id: {
        type: DataTypes.STRING,
        allowNull: false
      },    
    administrator: {
      type: DataTypes.BOOLEAN,
      alowNull: true
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false
    },
    first_name: {
      type: DataTypes.STRING,
      allowNull: true
    },
    last_name: {
      type: DataTypes.STRING,
      allowNull: true
    },
    street: {
      type: DataTypes.STRING,
      allowNull: true
    },
    zip: {
      type: DataTypes.STRING,
      allowNull: true
    },
    place: {
      type: DataTypes.STRING,
      allowNull: true
    },
    country: {
      type: DataTypes.STRING,
      allowNull: true
    },
    telno: {
      type: DataTypes.STRING,
      allowNull: true
    },
    email: {
      type: DataTypes.STRING,
      allowNull: true
    },
    IBAN: {
      type: DataTypes.STRING,
      allowNull: true
    },
    BIC: {
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    tableName: 'user',
    freezeTableName: true,
    classMethods: {
    	associate: function(db) {
    		db['user'].hasMany(db['contract'], {as: 'contracts', foreignKey: 'user_id'});
    	}
	},
  	instanceMethods: {
  		isAdmin: function() {
  			if (this.administrator) {
  				return true;
  			}
  		},
  		getAggregateNumbers: function() {
  			var aggregate = {open:0, openSum:0, paid:0, paidSum:0, terminated:0, terminatedSum:0, status:"C"};
  			var count = 0;
  			this.contracts.forEach(function(contract) {
  				count ++;
  				if (contract.status !== "complete") {
  					aggregate.status = "O";
  				}
  				if (contract.termination_date) {
  					aggregate.terminated++;
  					aggregate.terminatedSum += contract.amount;
  				} else {
  					var sum = 0;
  					contract.transactions.forEach(function (transaction){
  						sum+=transaction.amount;
  					});
  					if (sum >= contract.amount) {
  						aggregate.paid ++;
  						aggregate.paidSum += contract.amount; 
  					} else {
  						aggregate.open ++;
  						aggregate.openSum += contract.amount - sum;
  						aggregate.paidSum += sum;
  					}  					
  				}
  			});  	
  			if (count === 0) {
  				aggregate.status = "O";
  			}
  			return aggregate;
  		}
  	},
  	hooks: {
        beforeCreate: function (user, options) {
            user.logon_id = Math.abs(Math.random() * 100000000);
            console.log("logonid" + user.logon_id);
        },
  		afterCreate: function(user, options) {
  		  var id = user.id + 10000;
  		  return user.update({
  		    logon_id: id + "_willyfred" 
  		  }, {
  		    where: {
  		      id: user.id
  		    }
  		  });
  		}
    }
  });
  return User;
};
