var DocxGen = require('docxtemplater');
var JSZipUtils = require('jszip');
var fs = require('fs');


exports.generateDocx = function(templateFile, outputFile, data){
	
	var file = fs.readFileSync("./templates/docx/" + templateFile + ".docx", 'binary');
		var zip = new JSZipUtils(file);
        var doc=new DocxGen(zip);
        doc.setData(data); 
        doc.render();
        var out=doc.getZip().generate({type:"nodebuffer"});
        fs.writeFileSync("./tmp/"+ outputFile +".docx", out);
        console.log("done");
};